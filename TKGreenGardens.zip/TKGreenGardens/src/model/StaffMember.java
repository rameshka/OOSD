package model;

public class StaffMember extends HotelStaff {

    public StaffMember() {

    }

}
