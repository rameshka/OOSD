/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Malsha
 */
public class AssistantManager extends People {

    public void updateRoomPrices(Room room, int newPrice) {
    }

    public void updateHallPrices(Hall hall) {
    }

    public void updateOffer(int amount, String description) {
    }
}
