/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Malsha
 */
public class Payment {
    private int totalAmount;
    private int paidAmount;
    private int dueAmount;
    
    public Payment(){
        
    }
}
