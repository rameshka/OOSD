/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;


/**
 *
 * @author Malsha
 */
public class Manager extends People{
    
    
    
  
    
    public void addEmployee(String name, int ID, int salary, Date dateOfRecruitment){
    }
    
    public void addExpenditure(int amount, String description){
        //pass date via the prameters
    }
    
    public void addGain(int amount, String description){
        //pass date via the prameters
    }
    
    public void updateEmployee(int NIC){
    }
   
}
